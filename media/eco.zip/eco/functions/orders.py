from fastapi import HTTPException
from sqlalchemy import and_, cast, Date, func
from sqlalchemy.orm import joinedload
from pydantic.datetime_parse import datetime, date
from functions.customers import one_customer
from functions.restart import last_restart, one_restart
from functions.users import one_user

from models.customers import Customers

import datetime
from models.orders import Orders
from models.restart import Restart

from utils.pagination import pagination


def all_orders(search, status, userid, customerid, start_date, end_date, season_id, page, limit, db):
	if search:
		search_formatted="%{}%".format(search)
		search_filter=Orders.comment.like(search_formatted) | Orders.savdo_id.like(search_formatted)
	else:
		search_filter=Orders.id > 0
	if status in [True, False]:
		status_filter=Orders.status == status
	else:
		status_filter=Orders.status.in_([True, False])
	season=last_restart(db)
	if not season_id:
		season_filter=Orders.season_id == season.id
	else:
		season_filter=Orders.season_id == season_id
	if userid:
		userfilter=Orders.user_id == userid
	else:
		userfilter=Orders.user_id > 0
	if customerid:
		customerfilter=Orders.customer_id == customerid
	else:
		customerfilter=Orders.customer_id > 0
	
	try:
		if not start_date:
			start_date=datetime.date.min
		if not end_date:
			end_date=datetime.date.today()
		end_date=datetime.datetime.strptime(str(end_date), '%Y-%m-%d').date() + datetime.timedelta(days=1)
	except Exception as error:
		raise HTTPException(status_code=400, detail="Faqat yyyy-mmm-dd formatida yozing  ")
	orders=db.query(Orders).options(
		joinedload(Orders.customer).load_only(Customers.name),
		joinedload(Orders.season).load_only(Restart.year, Restart.part)).filter(Orders.date > start_date).filter(
		Orders.date <= end_date).filter(search_filter, userfilter, customerfilter, status_filter,
	                                    season_filter).order_by(Orders.id.desc())
	
	if page and limit:
		return pagination(orders, page, limit)
	else:
		return orders.all()


def one_order(id, db):
	data=db.query(Orders).options(
		joinedload(Orders.customer).load_only(Customers.name),
		joinedload(Orders.season).load_only(Restart.year, Restart.part)).filter(Orders.id == id).first()
	
	return data


def last_savdo(db):
	season=last_restart(db)
	
	return db.query(Orders).filter(Orders.season_id == season.id).order_by(Orders.id.desc()).first()


def create_order(form, user, db):
	if one_user(user.id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli foydalanuvchi mavjud emas")
	
	if one_customer(form.customer_id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli mijoz mavjud emas")
	
	season=last_restart(db)
	if not season:
		raise HTTPException(status_code=400, detail="Yil va bo'lim kiritilmagan ")
	savdo=last_savdo(db)
	if savdo:
		savdo_id=savdo.savdo_id + 1
		new_order_db=Orders(
			customer_id=form.customer_id,
			comment=form.comment,
			user_id=user.id,
			savdo_id=savdo_id,
			season_id=season.id,
			deadline=form.deadline
		
		)
		db.add(new_order_db)
		db.commit()
		db.refresh(new_order_db)
		return {'data': "Amaliyot muvaffaqiyatli amalga oshirildi", "id": new_order_db.id}
	
	else:
		savdo=1
		new_order_db=Orders(
			customer_id=form.customer_id,
			comment=form.comment,
			user_id=user.id,
			savdo_id=savdo,
			season_id=season.id,
			deadline=form.deadline)
		db.add(new_order_db)
		db.commit()
		db.refresh(new_order_db)
		return {'data': "Amaliyot muvaffaqiyatli amalga oshirildi", "id": new_order_db.id}


def update_order(form, user, db):
	if one_order(form.id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli mahsulot mavjud emas")
	
	if one_user(user.id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli user mavjud emas")
	
	db.query(Orders).filter(Orders.id == form.id).update({
		Orders.id: form.id,
		Orders.customer_id: form.customer_id,
		Orders.status: form.status,
		Orders.comment: form.comment,
		Orders.user_id: user.id,
		Orders.deadline: form.deadline
		
	})
	db.commit()
	return one_order(form.id, db)


def update_order_status(order_id, user_id, db):
	if one_order(order_id, db) is None:
		raise HTTPException(status_code=400, detail=f"Bunday {order_id} raqamli order mavjud emas")
	if one_user(user_id, db) is None:
		raise HTTPException(status_code=400, detail=f"Bunday {user_id} raqamli user mavjud emas")
	
	db.query(Orders).filter(Orders.id == order_id).update({
		Orders.status: False,
		
	})
	db.commit()
	return one_order(order_id, db)


def update_order_status_via_season_id(season_id, user_id, db):
	if one_restart(season_id, db) is None:
		raise HTTPException(status_code=400, detail=f"Bunday {season_id} raqamli season mavjud emas")
	if one_user(user_id, db) is None:
		raise HTTPException(status_code=400, detail=f"Bunday {user_id} raqamli user mavjud emas")
	seasons=db.query(Orders).filter(Orders.season_id == season_id).all()
	print(seasons, '------------------------*****************************************************************')
	for season in seasons:
		db.query(Orders).filter(Orders.id == season.id).update({
			Orders.status: False,
			
		})
		db.commit()
	return {"date": "Ma'lumot o'chirildi !"}


def order_delete(id, user, db):
	if one_order(id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli ma'lumot mavjud emas")
	db.query(Orders).filter(Orders.id == id).update({
		Orders.status: False,
		Orders.user_id: user.id
	})
	db.commit()
	return {"date": "Ma'lumot o'chirildi !"}

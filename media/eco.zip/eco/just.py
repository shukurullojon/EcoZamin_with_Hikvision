import datetime

print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M")=="2023-04-27 15:51")
print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
"2023-04-27 11:30:21"
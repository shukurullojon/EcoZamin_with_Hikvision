from db import SessionLocal
from fastapi import FastAPI
from fastapi_utils.tasks import repeat_every
from sqlalchemy.orm import Session

from functions.done import check_todo_workr_result
from functions.other_works import select_other_works_deadline
from routes import auth, users, phones, customers, products, orders, trades, kpi, kpi_history, \
	incomes, expenses, extra, nasiya, for_websocket, todo, done, extraworks, end_time, other_works, restart
from db import Base, engine
import datetime



Base.metadata.create_all(bind=engine)

app=FastAPI(
	title="Eko zamin",
)

from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
	CORSMiddleware,
	allow_origins=['*'],
	allow_credentials=True,
	allow_methods=["*"],
	allow_headers=["*"],
)


@app.get('/')
def home():
	return {"message": "Welcome"}


app.include_router(
	auth.login_router,
	prefix='/auth',
	tags=['User auth section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	users.router_user,
	prefix='/user',
	tags=['User section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	phones.router_phone,
	prefix='/phone',
	tags=['Phone section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	customers.router_customer,
	prefix='/customer',
	tags=['Customer section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	products.router_product,
	prefix='/product',
	tags=['Product section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	orders.router_order,
	prefix='/order',
	tags=['Order section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	trades.router_trade,
	prefix='/trade',
	tags=['Trade section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	kpi.router_kpi,
	prefix='/kpi',
	tags=['Kpi section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	kpi_history.router_kpi_history,
	prefix='/kpi_history',
	tags=['Kpi history section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	incomes.router_income,
	prefix='/income',
	tags=['Income section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	expenses.router_expense,
	prefix='/expense',
	tags=['Expense section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	extra.router_extra,
	prefix='/extra',
	tags=['Extra section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	nasiya.router_nasiya,
	prefix='/nasiya',
	tags=['Nasiya section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	for_websocket.notification_router,
	prefix='',
	tags=['websocket  section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	todo.router_todo,
	prefix='/todo',
	tags=['Todo  section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	done.router_done,
	prefix='/done',
	tags=['Done  section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	extraworks.router_extrawork,
	prefix='/extraworks',
	tags=['Extraworks  section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	end_time.router_end_time,
	prefix='/time',
	tags=['Time  section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	other_works.router_other_work,
	prefix='/otherworks',
	tags=['Other works  section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)

app.include_router(
	restart.router_restart,
	prefix='/restart',
	tags=['Restart  section'],
	responses={200: {'description': 'Ok'}, 201: {'description': 'Created'}, 400: {'description': 'Bad Request'},
	           401: {'desription': 'Unauthorized'}}
)


@app.on_event("startup")
@repeat_every(seconds=3600, wait_first=True)
async def check():
	
		timee=datetime.datetime.now().strftime("%H") == "00"
		
		if timee:
			await select_other_works_deadline()


@app.on_event("startup")
@repeat_every(seconds=3600, wait_first=True)
async def check_todo():
	timee=datetime.datetime.now().strftime("%H") == "00"
	
	if timee:
		await check_todo_workr_result()

import datetime

from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload

from functions.kpi_history import update_history_status
from models.kpi_history import Kpi_History
from functions.kpi import one_kpi, filter_kpi
from functions.nasiya import filter_nasiya, nasiya_update_, update_nasiya_status_via_order
from functions.trades import one_trade
from functions.orders import one_order
from functions.users import one_user, update_user_salary, filter_users, update_user_balance
from models.incomes import Incomes
from models.orders import Orders
from routes.notification import manager
from schemas.notification import NotificationBase

from utils.pagination import pagination


def all_incomes(search, status, order_id,customer_id,start_date,end_date, page, limit, db):
	if search:
		search_formatted="%{}%".format(search)
		search_filter=Incomes.money.like(search_formatted)
	else:
		search_filter=Incomes.id > 0
	if status in [True, False]:
		status_filter=Incomes.status == status
	else:
		status_filter=Incomes.status.in_([True, False])
	
	if order_id:
		order_filter=Incomes.source_id == order_id
	else:
		order_filter=Incomes.source_id > 0
	
	if customer_id:
		customer_filter=Incomes.user_id == customer_id
	else:
		customer_filter=Incomes.user_id > 0
	
	
	
	try:
		if not start_date:
			start_date=datetime.date.min
		if not end_date:
			end_date=datetime.date.today()
		end_date=datetime.datetime.strptime(str(end_date), '%Y-%m-%d').date() + datetime.timedelta(days=1)
	except Exception as error:
		raise HTTPException(status_code=400, detail="Faqat yyyy-mmm-dd formatida yozing  ")
	
	incomes=db.query(Incomes).options(
			joinedload(Incomes.order)).filter(Orders.date > start_date).filter(
			Orders.date <= end_date).filter(search_filter, status_filter, order_filter, customer_filter).order_by(
			Incomes.id.desc())
	if page and limit:
			return pagination(incomes, page, limit)
		
	else:
			return incomes.all()


def one_income(id, db):
	return db.query(Incomes).options(
        joinedload(Incomes.order).load_only(Orders.savdo_id,)).filter(Incomes.id == id).first()


async def create_income(form, cur_user, db):
	if one_user(cur_user.id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli foydalanuvchi mavjud emas")
	
	if one_order(form.source_id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli savdo mavjud emas")
	
	new_income_db=Incomes(
		money=form.money,
		type=form.type,
		source_id=form.source_id,
		source=form.source,
		user_id=cur_user.id,
	
	)
	db.add(new_income_db)
	db.commit()
	db.refresh(new_income_db)
	get_order=one_order(id=form.source_id, db=db)
	nasiya=filter_nasiya(order_id=form.source_id, db=db)
	if nasiya:
		nasiya_money=nasiya.money - form.money
		if nasiya_money<0:
			
			raise HTTPException(status_code=400,
			                    detail=f"{form.source_id} id raqamli nasiyaga orticha {-1*nasiya_money} so'm to'lov qilinyapti")
		user_kpi=filter_kpi(source_id=cur_user.id, db=db)
		money1=user_kpi.percentage * form.money / 100
		user=one_user(id=cur_user.id, db=db)
		updated_salary=user.salary + money1
		
		update_user_salary(id=cur_user.id, salary=updated_salary, db=db)
		updated_balance=user.balance - money1
		update_user_balance(id=cur_user.id,balance=updated_balance,db=db)
		new_history_db=Kpi_History(
			money=money1,
			type=form.type,
			order_id=form.source_id,
			comment='',
			user_id=cur_user.id,
			return_date=datetime.datetime.now(),
		
		)
		db.add(new_history_db)
		db.commit()
		db.refresh(new_history_db)
		update_history_status(order_id=form.source_id,user_id=cur_user.id,db=db)
		users=filter_users(roll='worker', db=db)
		data=NotificationBase(
			money=money1,
			worker_id=user.id,
			order_id=form.source_id,
			savdo_id=get_order.savdo_id,
			user_id=cur_user.id,
			name=user.name,
			type="trade"
		)
		await manager.send_user(message=data, user_id=user.id, db=db)
		for worker in users:
			worker_kpi=filter_kpi(source_id=worker.id, db=db)
			money=worker_kpi.percentage * form.money / 100
			user=one_user(id=worker.id, db=db)
			updated_salary=user.salary + money
			update_user_salary(id=worker.id, salary=updated_salary, db=db)
			updated_balance=user.balance - money
			update_user_balance(id=worker.id, balance=updated_balance, db=db)
			new_history_db=Kpi_History(
				money=money,
				type=form.type,
				order_id=form.source_id,
				comment='',
				user_id=worker.id,
				return_date=datetime.datetime.now())
			db.add(new_history_db)
			db.commit()
			update_history_status(order_id=form.source_id, user_id=worker.id, db=db)
			data=NotificationBase(
				money=money,
				worker_id=worker.id,
				order_id=form.source_id,
				savdo_id=get_order.savdo_id,
				user_id=cur_user.id,
				name=user.name,
				type="trade"
			)
			await manager.send_user(message=data, user_id=worker.id, db=db)
			
			
		
		
		if nasiya_money > 0:
			nasiya_update_(order_id=form.source_id, money=nasiya_money, db=db)
		elif nasiya_money == 0:
			nasiya_update_(order_id=form.source_id, money=0, db=db)
			update_nasiya_status_via_order(order_id=form.source_id, db=db)
			
			raise HTTPException(status_code=400, detail=f"{form.source_id} id raqamli nasiya to'liq qoplandi!")
			
		
	return new_income_db


def update_income(form, cur_user, db):
	if one_income(form.id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli income mavjud emas")
	
	if one_user(cur_user.id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli user mavjud emas")
	
	
	
	db.query(Incomes).filter(Incomes.id == form.id).update({
		Incomes.money: form.money,
		Incomes.type: form.type,
		Incomes.source_id: form.source_id,
		Incomes.source: form.source,
		Incomes.user_id: cur_user.id,
		Incomes.status: form.status
	})
	db.commit()
	return one_income(form.id, db)

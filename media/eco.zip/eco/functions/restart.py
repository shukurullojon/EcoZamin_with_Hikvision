from fastapi import HTTPException
from functions import orders
from functions.users import one_user
from models.restart import Restart
from utils.pagination import pagination


def all_restarts(search, status, page, limit, db):
    if search:
        search_formatted = "%{}%".format(search)
        search_filter = Restart.name.like(search_formatted) | Restart.birlik.like(
            search_formatted) | Restart.price.like(search_formatted)
    else:
        search_filter = Restart.id > 0
    if status in [True, False]:
        status_filter = Restart.status == status
    else:
        status_filter = Restart.status.in_([True, False])

    restart = db.query(Restart).filter(search_filter, status_filter).order_by(Restart.id.desc())
    if page and limit:
        return pagination(restart, page, limit)
    else:
        return restart.all()


def one_restart(id, db):
    return db.query(Restart).filter(Restart.id == id).first()

def last_restart(db):
    return db.query(Restart).filter(Restart.status==True).order_by(Restart.id.desc()).first()

def create_restart(form, user, db):
    new_restart_db = Restart(
        year=form.year,
        part=form.part,
        user_id=user.id,

    )

    db.add(new_restart_db)
    db.commit()


    return new_restart_db


def update_restart(form, user, db):
    if one_restart(form.id, db) is None:
        raise HTTPException(status_code=400, detail="Bunday id raqamli mahsulot mavjud emas")

    if one_user(user.id, db) is None:
        raise HTTPException(status_code=400, detail="Bunday id raqamli user mavjud emas")

    db.query(Restart).filter(Restart.id == form.id).update({
        Restart.year: form.year,
        Restart.part: form.part,
        Restart.status: form.status,
        Restart.user_id: user.id,
    })
    db.commit()
    return one_restart(form.id, db)


def restart_delete(id, user, db):
    if one_restart(id, db) is None:
        raise HTTPException(status_code=400, detail="Bunday id raqamli mahsulot mavjud emas")
    db.query(Restart).filter(Restart.id == id).update({
        Restart.status: False,
        Restart.user_id: user.id
    })
    db.commit()
    return {"date": "Mahsulot o'chirildi !"}
from time import sleep

from fastapi import HTTPException, WebSocket

from functions.kpi import one_kpi, filter_kpi
from functions.orders import update_order_status, one_order
from functions.trades import one_trade, get_order_id_from_trades, get_deadline_from_trades
from functions.users import one_user, update_user_salary, all_users, filter_users, update_user_balance
from models.incomes import Incomes
from models.kpi_history import Kpi_History
from models.nasiya import Nasiya
from models.extra import Extra
from routes.notification import manager
from schemas.notification import NotificationBase

from utils.pagination import pagination


def all_history(search, status, source_id, page, limit, db):
	if search:
		search_formatted = "%{}%".format(search)
		search_filter = Kpi_History.money.like(search_formatted) | Kpi_History.order_id.like(
			search_formatted)
	else:
		search_filter = Kpi_History.id > 0
	if status in [True, False]:
		status_filter = Kpi_History.status == status
	else:
		status_filter = Kpi_History.status.in_([True, False])

	if source_id:
		source_id_filter = Kpi_History.order_id == source_id
	else:
		source_id_filter = Kpi_History.id > 0

	history = db.query(Kpi_History).filter(search_filter, status_filter, source_id_filter).order_by(
		Kpi_History.id.desc())

	if page and limit:
		return pagination(history, page, limit)
	else:
		return history.all()


def one_history(id, db):
	return db.query(Kpi_History).filter(Kpi_History.id == id).first()


def all_payments(user_id, page, limit, db):
	history = db.query(Kpi_History).filter(Kpi_History.user_id == user_id).all()
	extra = db.query(Extra).filter(Extra.source_id == user_id).all()
	history = history + extra
	if page and limit:
		return pagination(history, page, limit)
	else:
		return history


async def create_history(form, cur_user, db):
	if one_user(cur_user.id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli foydalanuvchi mavjud emas")

	if one_order(form.order_id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli savdo mavjud emas")

	# update user salary section
	user_kpi = filter_kpi(source_id=cur_user.id, db=db)
	get_order = one_order(id=form.order_id,db=db)
	if not user_kpi:
		raise HTTPException(status_code=400, detail="Sizga kpi yaratilmagan")
	money = user_kpi.percentage * form.money / 100
	user = one_user(id=cur_user.id, db=db)
	real_money = get_order_id_from_trades(id=form.order_id, user=cur_user.id, db=db).get('money')

	updated_salary = user.salary + money
	update_user_salary(id=cur_user.id, salary=updated_salary, db=db)
	data = NotificationBase(
		money=money,
		worker_id=user.id,
		order_id=form.order_id,
		savdo_id=get_order.savdo_id,
		user_id=cur_user.id,
		name=user.name,
		type="trade"

	)
	await manager.send_user(message=data, user_id=user.id, db=db)
	
	new_history_db=Kpi_History(
		money=money,
		type=form.type,
		order_id=form.order_id,
		comment=form.comment,
		user_id=cur_user.id,
		return_date=form.return_date)
	db.add(new_history_db)
	db.commit()
	
	users = filter_users(roll='worker', db=db)
	for worker in users:
		worker_kpi = filter_kpi(source_id=worker.id, db=db)
		money = worker_kpi.percentage * form.money / 100
		user = one_user(id=worker.id, db=db)

		updated_salary = user.salary + money
		update_user_salary(id=worker.id, salary=updated_salary, db=db)
		data=NotificationBase(
			money=money,
			worker_id=worker.id,
			order_id=form.order_id,
			savdo_id=get_order.savdo_id,
			user_id=cur_user.id,
			name=user.name,
			type="trade"
		)
		await manager.send_user(message=data, user_id=worker.id, db=db )
		
		
		
		new_history_db=Kpi_History(
			money=money,
			type=form.type,
			order_id=form.order_id,
			comment=form.comment,
			user_id=worker.id,
			return_date=form.return_date)
		db.add(new_history_db)
		db.commit()
		
	

	if real_money == form.money:
		update_order_status(order_id=form.order_id, user_id=cur_user.id, db=db)

	elif real_money > form.money:
		user_kpi = filter_kpi(source_id=cur_user.id, db=db)
		nasiya = real_money - form.money
		money=user_kpi.percentage * nasiya / 100
		user=one_user(id=cur_user.id, db=db)
		updated_balance = user.balance + money
		update_user_balance(id=cur_user.id, balance=updated_balance, db=db)
		
		users = filter_users(roll='worker', db=db)
		for worker in users:
			worker_kpi = filter_kpi(source_id=worker.id, db=db)
			money = worker_kpi.percentage * nasiya / 100
			user = one_user(id=worker.id, db=db)
			
			updated_balance = user.balance + money
			update_user_balance(id=worker.id, balance=updated_balance, db=db)
			

		order = one_order(id=form.order_id, db=db)

		new_history_db = Nasiya(
			money=nasiya,
			order_id=form.order_id,
			customer_id=order.customer_id,
			deadline=form.return_date,
			user_id=cur_user.id,

		)
		db.add(new_history_db)
		db.commit()

		update_history_status(order_id=form.order_id, user_id=cur_user.id, db=db)
		update_order_status(order_id=form.order_id, user_id=cur_user.id, db=db)


	else:
		extra = form.money - real_money
		raise HTTPException(status_code=400, detail=f"Ortiqcha to'lov qilindi {extra} so'm")

	new_income_db = Incomes(
		money=form.money,
		type=form.type,
		source_id=form.order_id,
		source="trade",
		user_id=cur_user.id
	)
	db.add(new_income_db)
	db.commit()

	return new_income_db


def update_history(form, cur_user, db):
	if one_history(form.id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli savdo tarixi mavjud emas")

	if one_user(cur_user.id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli user mavjud emas")

	if one_trade(form.order_id, db) is None:
		raise HTTPException(status_code=400, detail="Bunday id raqamli savdo mavjud emas")

	db.query(Kpi_History).filter(Kpi_History.id == form.id).update({
		Kpi_History.money: form.money,
		Kpi_History.type: form.type,
		Kpi_History.order_id: form.order_id,
		Kpi_History.status: form.status,
		Kpi_History.comment: form.comment,
		Kpi_History.user_id: cur_user.id
	})
	db.commit()
	return one_history(form.id, db)


def update_history_status(order_id, user_id, db):
	if one_order(order_id, db) is None:
		raise HTTPException(status_code=400, detail=f"Bunday {order_id} raqamli order mavjud emas")
	if one_user(user_id, db) is None:
		raise HTTPException(status_code=400, detail=f"Bunday {user_id} raqamli user mavjud emas")

	db.query(Kpi_History).filter(Kpi_History.order_id == order_id).update({
		Kpi_History.status: False,

	})
	db.commit()
	return one_history(order_id, db)


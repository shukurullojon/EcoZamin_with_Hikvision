from pydantic import BaseModel
from pydantic.datetime_parse import date

class RestartBase(BaseModel):
    year: str
    part: str


class RestartCreate(RestartBase):
    pass


class RestartUpdate(RestartBase):
    id: int
    status: bool

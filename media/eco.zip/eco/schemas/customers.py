from typing import List

from pydantic import BaseModel
from schemas.phones import PhoneBase

class CustomerBase(BaseModel):
	name: str
	address: str



class CustomerCreate(CustomerBase):
	phones : List[PhoneBase]


class CustomerUpdate(CustomerBase):
	phones: List[PhoneBase]
	id: int
	status: bool

	

class CustomerOut(CustomerBase):
		id: int
		user_id: int
		status: bool
		phones : list = []

		class Config:
			orm_mode = True




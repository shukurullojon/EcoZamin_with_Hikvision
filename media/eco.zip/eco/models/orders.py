import uuid

from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Boolean, func, and_, Identity
from sqlalchemy.orm import relationship, backref

import db
from db import Base
from models.customers import Customers


class Orders(Base):
    __tablename__ = "Orders"
    id = Column(Integer, primary_key=True, )
    savdo_id = Column(Integer,nullable=False, )
    customer_id = Column(Integer,ForeignKey('Customers.id'), nullable=False)
    comment = Column(String(200),nullable=True)
    user_id = Column(Integer,ForeignKey("Users.id"), nullable=False)
    date = Column(DateTime(timezone=True), default=func.now(), nullable=False)
    deadline = Column(DateTime(timezone=True), nullable=False)
    status = Column(Boolean, nullable=False, default=True)
    season_id = Column(Integer,ForeignKey("Restart.id"),nullable=False)
	
    history = relationship("Kpi_History",back_populates="order")
    customer = relationship("Customers",back_populates="orders",lazy='joined')
    nasiya = relationship("Nasiya",back_populates="order_nasiya")
    season = relationship("Restart",back_populates="order")
    user = relationship("Users",back_populates = 'order')


    
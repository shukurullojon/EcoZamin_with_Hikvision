from fastapi import APIRouter, Depends, HTTPException
from db import Base, engine, get_db

from sqlalchemy.orm import Session

from routes.auth import get_current_active_user

Base.metadata.create_all(bind=engine)

from functions.restart import one_restart, all_restarts, create_restart, update_restart, restart_delete
from schemas.restart import *
from schemas.users import UserCurrent

router_restart = APIRouter()


@router_restart.post('/add', )
def add_restart(form: RestartCreate, db: Session = Depends(get_db), current_user: UserCurrent = Depends(
    get_current_active_user)):  # current_user: CustomerBase = Depends(get_current_active_user)
    if create_restart(form, current_user, db):
        raise HTTPException(status_code=200, detail="Amaliyot muvaffaqiyatli amalga oshirildi")


@router_restart.get('/', status_code=200)
def get_restarts(search: str = None, status: bool = True, id: int = 0, page: int = 1, limit: int = 25,
             db: Session = Depends(get_db), current_user: UserCurrent = Depends(
            get_current_active_user)):  # current_user: User = Depends(get_current_active_user)
    if id:
        return one_restart(id, db)
    else:
        return all_restarts(search, status, page, limit, db, )


@router_restart.put("/update")
def restart_update(form: RestartUpdate, db: Session = Depends(get_db),
               current_user: RestartBase = Depends(get_current_active_user)):
    if update_restart(form, current_user, db):
        raise HTTPException(status_code=200, detail="Amaliyot muvaffaqiyatli amalga oshirildi")


@router_restart.delete('/{id}', status_code=200)
def delete_restart(id: int = 0, db: Session = Depends(get_db), current_user: UserCurrent = Depends(
    get_current_active_user)):  # current_user: User = Depends(get_current_active_user)
    if id:
        return restart_delete(id, current_user, db)


